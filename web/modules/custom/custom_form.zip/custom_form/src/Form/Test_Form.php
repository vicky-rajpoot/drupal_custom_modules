<?php
namespace Drupal\custom_form\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\node\Entity\Node;


class Test_Form extends FormBase 
{
    
    public function getFormId() {
        return 'form_id';
    }

    public function buildForm(array $form, FormStateInterface $form_state) {
        $form['username'] = array(
          '#type' => 'textfield',
          '#title' => t('Enter username:'),
          '#required' => TRUE,
        );
        $form['useremail'] = array(
          '#type' => 'email',
          '#title' => t('Enter Email ID:'),
          '#required' => TRUE,
        );
        $form['user_phone'] = array (
          '#type' => 'tel',
          '#title' => t('Enter Contact Number'),
        );
        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = array(
          '#type' => 'submit',
          '#value' => $this->t('Register'),
          '#ajax' => [
            'callback' => '::setMessage',
        ],
        );
        $form['message'] = [
            '#type' => 'markup',
            '#markup' => '<div class="result_message"></div>',
        ];
        return $form;
      }
        public function validateForm(array &$form, FormStateInterface $form_state) {
        if(strlen($form_state->getValue('username')) < 3) {
          $form_state->setErrorByName('username', $this->t('Please enter a valid Name'));
        }
        if(strlen($form_state->getValue('user_phone')) < 10) {
          $form_state->setErrorByName('user_phone', $this->t('Please enter a valid Contact Number'));
        }
      }
      public function setMessage(array $form, FormStateInterface $form_state) 
      {
        $response = new AjaxResponse();
              $response->addCommand(
                new HtmlCommand(
                    '.result_message',
                    '<div class="my_message">Submitted name is ' . $form_state->getValue('username') . '</div>')
                );
            
        return $response;
     }
      public function submitForm(array &$form, FormStateInterface $form_state) 
      {
        
          // $output =$form_state->getValues();
          $name=$form_state->getvalue(['username']);
          $email=$form_state->getvalue(['useremail']);
          $phone=$form_state->getvalue(['user_phone']);
          $x = array();
          $x[] = $name;
          $x[] = $email;
          $x[] = $phone;
          $output= implode(",",$x);
          $node = Node::create([
            'type'  => 'clothes',
            'title' => $name,
            'body' => $output,
          ]);
          $node->save();
      }
}
?>